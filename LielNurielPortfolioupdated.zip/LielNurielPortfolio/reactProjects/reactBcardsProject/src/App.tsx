
import './App.css'
import Defaout from './layouts/Default/Defaout'

export default function App() {
  return (
    <div className='App'>
      <Defaout></Defaout>
    </div>
  )
}
