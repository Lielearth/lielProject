
import { useEffect, useState } from 'react'



interface Icard {
    _id:string
    title:string
    description:string
    image:{url:string, alt:string}
    bizNumber:number
    user_id:string
    phone:number
    address:{country:string, city:string}
    likes: []
  }
  
  

export default function Favories() {


    const [cards, setCards] = useState<null|Icard[]>(null)
    const [error, setError] = useState<null|string>(null)

    useEffect( ()=> {
        const fetchFavCards = async() =>{
          try{
            const response = await fetch('https://monkfish-app-z9uza.ondigitalocean.app/bcard2/cards', {
              method:'GET',
              headers:{
            'Content-Type': 'application/json',
            }
            })
            const data = await response.json()  
            setCards(data)
          }catch(err){
            const errMessage = (err as Error).message
            setError(errMessage)
          }
        }
        fetchFavCards()
        }
        ,[]
        )


  return (
    <>
    <div className="Favories Home">
        <h3>Favorit cards</h3>
        {(error) && <p>Error getting cards! <br />{error}</p>}
        <div className='container'>
        {
          (cards)?
          cards?.filter(cards => cards.user_id=='653a608d1c7cd80c1fd27532').map((cards)=>
          <div className="card" key={cards._id}>
          <img src={cards.image.url} className="card-img-top" alt={cards.image.alt}/>
         <div className="card-body text-bg-dark">
         <h5 className="card-title">{cards.title}</h5>
         <p className="card-text">{cards.description}</p>
         <p className="card-text">{cards.bizNumber}</p>
        </div>
      </div>
      )
      :
      (!error) && 'No cards'
      }
    </div>
    </div>
    </>
  )
}
