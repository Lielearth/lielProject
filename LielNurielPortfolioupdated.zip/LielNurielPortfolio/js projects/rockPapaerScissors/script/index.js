'use strict'

//pseodo cod

//rock paper scissors
//about the game and how it works
//the moment the player press play he can choose between three options: rock, papaer, scissors
//the we get the player's pick and the computer picks an option between the three randomly
//now the game starts and can divalop in several ways:
//posibility 1: player choose rock, computer choose rock      :     even
//posibility 2: Player choose rock, comuter choose paper      :     computer win
//posibility 3: Player choose rock computer choose scissors   :     player win
//posibility 4: player choose paper, computer choose rock     :     player win
//posibility 5: Player choose paper, comuter choose paper     :     even
//posibility 6: Player choose paper,computer choose scissors  :     computer win
//posibility 7: player choose scissors, computer choose rock  :     computer win
//posibility 8: Player choose scissors, comuter choose paper  :     player win
//posibility 9: Player choose scissors, computer choose scissors:   even
//at the end of every round the winer gets 1 point
//optional:::::::::::after 3 rounds the game ends and declears the winner and there is an option to start again 


//coding instructions in small tasks
//1.references
//2.set up veraiables
//3.start breaking the game to rownds 
//4. funcion play- start the game and let the player choose 
//5. put a function in onclick on every option and the event will activate the function that would get the computer's chooise 
//and decide the winner acording to the 9 options avilable. :::: choose if or switch....
//6. the function would let us know how won: first by console, then by coloring the winning weapon//think of adding a message that annonce it
//7.optional::::::::::::end the game after 3 rounds and set a button to play again



//1.references

const elmUserScore = document.querySelector('#player-score');
const elmComputerScore = document.querySelector('#computer-score');
const elmMessage = document.querySelector('#Message');
const elmLastComputerChoise = document.querySelector('#computer-choice');
const elmRock = document.querySelector('#rock');
const elmPaper = document.querySelector('#paper');
const elmScissors = document.querySelector('#scissors');
const elmChoicesContainer = document.querySelector('.choices');
const elmUserBored = document.querySelector('.player-score');
const elmComputerBoard = document.querySelector('.computer-score');



//2.set up veraiables//to complete.

const options = ['Rock', 'Paper', 'Scissors']
let userChoise;


//play again

function playAgain (){
    elmComputerScore.innerHTML = 0;
    elmUserScore.innerHTML = 0;
    elmMessage.innerText = 'Choose your weapon!';
    elmUserBored.style.backgroundColor = 'white';
    elmComputerBoard.style.backgroundColor = 'white';
    elmChoicesContainer.style = 'display:block';
    elmChoicesContainer.style = 'display:flex'
    elmLastComputerChoise.style = 'display:block';
    elmMessage.style = 'display:block';
}

//game over//not working for some reason//

function gameOver (){
if(elmUserScore.innerHTML === "10"){
    elmChoicesContainer.style = 'display:none';
    elmLastComputerChoise.style = 'display:none';
    elmMessage.style = 'display:none';
    elmUserBored.style.backgroundColor = 'rgb(27, 223, 119)';
}
else if(elmComputerScore.innerHTML === "10"){
    elmChoicesContainer.style = 'display:none';
    elmLastComputerChoise.style = 'display:none';
    elmMessage.style = 'display:none';
    elmComputerBoard.style.backgroundColor = 'rgb(27, 223, 119)';
}else if (elmComputerScore.innerHTML === "10" && elmUserScore.innerHTML === "10"){
    elmChoicesContainer.style = 'display:none';
    elmLastComputerChoise.style = 'display:none';
    elmMessage.style = 'display:none';
    elmUserBored.style.backgroundColor = ' rgb(104, 102, 102)';
    elmComputerBoard.style.backgroundColor = ' rgb(104, 102, 102)';
}
return;
}



//game

function rock() {
    gameOver ()
    const computerChoice = Math.trunc(Math.random()*options.length);
    console.log(computerChoice);
    userChoise = options[0]
    console.log(userChoise);
    if(userChoise === options[0] && computerChoice === 1){
        elmComputerScore.innerHTML++
        elmMessage.innerText = 'Computer Won'
        elmLastComputerChoise.innerText = 'Last computer Choice: Paper'
    }
    else if(userChoise === options[0] && computerChoice === 2){
        elmUserScore.innerHTML++
        elmMessage.innerText = 'You Won!'
        elmLastComputerChoise.innerText = 'Last computer Choice: Scissors'
    }else{
        elmMessage.innerText ="You're Even"
        elmLastComputerChoise.innerText = 'Last computer Choice: Rock'
    }
}

function paper() {
    gameOver ()
    const computerChoice = Math.trunc(Math.random()*options.length);
    console.log(computerChoice);
    userChoise = options[1];
    console.log(userChoise);
    if(userChoise == options[1] && computerChoice == 2){
        elmComputerScore.innerHTML++
        elmMessage.innerText = 'Computer Won'
        elmLastComputerChoise.innerText = 'Last computer Choice: Scissors'
    }
    else if(userChoise == options[1] && computerChoice == 0){
        elmUserScore.innerHTML++
        elmMessage.innerText = 'You Won!'
        elmLastComputerChoise.innerText = 'Last computer Choice: Rock'
    }else{
        elmMessage.innerText ="You're Even"
        elmLastComputerChoise.innerText = 'Last computer Choice: Paper'
    }
}

function scissors() {
    gameOver ()
    const computerChoice = Math.trunc(Math.random()*options.length);
    console.log(computerChoice);
    userChoise = options[2];
    console.log(userChoise);
    if(userChoise == options[2] && computerChoice == 0){
        elmComputerScore.innerHTML++
        elmMessage.innerText = 'Computer Won'
        elmLastComputerChoise.innerText = 'Last computer Choice: Rock'
    }
    else if(userChoise == options[2] && computerChoice == 1){
        elmUserScore.innerHTML++
        elmMessage.innerText = 'You Won!'
        elmLastComputerChoise.innerText = 'Last computer Choice: Paper'
    }else{
        elmMessage.innerText ="You're Even"
        elmLastComputerChoise.innerText = 'Last computer Choice: Scissors'
    }
}



