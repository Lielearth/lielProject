'use strict'

//two player tic tac toe game
//a board with 9 tiles that each will be clickable
//needs to switch players after each click
//winning array pattern
//winning massege
//button to restart

/*
index in the board:
[0][1][2]
[3][4][5]
[6][7][8]
*/ 


//dom refernces
const elmBox = Array.from(document.querySelectorAll('.box'));
const elmMessage = document.querySelector('#message');
const elmBoardDisplay = document.querySelector('#board');
const elmStartButton = document.querySelector('#startButton');


//veraiables
const playerX = 'X'
const playerO = 'O'
let correntPlayer = playerX;
let spaces = Array(0).fill()



//diaplay the play screen
function startGame(){
    elmBoardDisplay.style = 'visibility:visible';
    elmStartButton.style = 'display:none';
    elmMessage.innerText = 'Click on a tile to play';
}


//makes each box clickable
const activateGame = () => {
elmBox.forEach(box => box.addEventListener("click", boxClicked));
}

//what every click does
function boxClicked(e) {
    const id = e.target.id
    if(!spaces[id]){
        e.target.innerText = correntPlayer
        spaces.push(correntPlayer);
        console.log(spaces);
        correntPlayer = correntPlayer == playerX ? playerO : playerX
        playerHasWon()
    }
}

//check the winning condiotions
function playerHasWon() {
    for (let i = 0; i < spaces.length; i++) {
            if(spaces[0,1,2]  === correntPlayer || spaces[3,4,5] === correntPlayer || 
                spaces[6,7,8] === correntPlayer || spaces[0,3,6] === correntPlayer ||
                spaces[1,4,7] === correntPlayer || spaces[2,5,8] === correntPlayer ||
                spaces[0,4,8] === correntPlayer || spaces[2,4,6] === correntPlayer){
                elmMessage.innerHTML = `${correntPlayer} has won!`
            }
    }
}

activateGame()

