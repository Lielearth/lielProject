Personal portfolio

This is a personal project gallery that displays my work and projects. Through this gallery, I present works in which I have participated and are presented through landing pages.

## Technologies in use

- HTML
- CSS
- Bootstrap
- JavaScript
- scss
-react
-node.js
- Graphic design and processing techniques

## Landing pages

Within each project, you can find a landing page. On the landing pages you can see the optimal design of the interface and delve into the details of the project itself.

## How to run the project:

If you are interested in running and testing the projects yourself, you should follow the following instructions:

1. Download the ZIP file or repository from GitHub.
2. Extract the zip files.
2. Open the index.html file in your browser if it is an HTML/javascript project.
3. If this is a react/node.js project, open the files and run in the terminal npm i and then npm run dev
4. Now you can see and browse the projects.

## Advice and support

If you have questions or problems with the projects or the code, you are welcome to open a request on GitHub on the Issues page. I am here to help and support!

Thank you for visiting my project gallery! I hope you enjoyed a look at my various creations.

---