'use strict'

//two player tic tac toe game
//a board with 9 tiles that each will be clickable
//needs to switch players after each click
//winning array pattern
//winning massege
//button to restart


//dom refernces
const elmBox = document.querySelector('.box');
const elmMessage = document.querySelector('#message');
const elmBoardDisplay = document.querySelector('#board');
const elmStartButton = document.querySelector('#startButton');
const elmAgaintButton = document.querySelector('#againButton');

let elmb1 = document.querySelector('#b1');
let elmb2 = document.querySelector('#b2');
let elmb3 = document.querySelector('#b3');
let elmb4 = document.querySelector('#b4');
let elmb5 = document.querySelector('#b5');
let elmb6 = document.querySelector('#b6');
let elmb7 = document.querySelector('#b7');
let elmb8 = document.querySelector('#b8');
let elmb9 = document.querySelector('#b9');


//veraiables
const playerX = 'X'
const playerO = 'O'
let correntPlayer = playerX;
let spaces = [elmb1, elmb2, elmb3, elmb4, elmb5, elmb6, elmb7, elmb8, elmb9];


//diaplay the play screen
function startGame(){
    elmBoardDisplay.style = 'visibility:visible';
    elmStartButton.style = 'display:none';
    elmMessage.innerText = 'Click on a tile to play';
    elmAgaintButton.style = 'visibility:hidden';
}


//makes each box clickable
function clickableBoxes() {
    spaces.forEach(e => {
    e.addEventListener("click", (e) => {switchPlayer(e) })
        }
    )
}


clickableBoxes()

//what happens after every click, switching players
const switchPlayer = (e) => {
    for (let i = 0; i < 1; i++) {
    const tile = e.target;
    if(correntPlayer == playerX){
    tile.innerText = playerX;   
        console.log(tile.id);
        tile.id = 'X'
        console.log(tile.id);
    elmMessage.innerText = `its ${correntPlayer}'s turn`
    correntPlayer = playerO;
    }else if(correntPlayer == playerO){
        tile.innerText = playerO;   
            console.log(tile.id);
            tile.id = 'O'
            console.log(tile.id);
        elmMessage.innerText = `its ${correntPlayer}'s turn`
        correntPlayer = playerX;
    }
    tile.disabled = true
    }
    console.log(spaces);
    whoIsWinner()
    };



/*check who won
winning combinations
123
456
789
741
852
963
753
951
*/
/*
index in the board:
[0][1][2]
[3][4][5]
[6][7][8]
*/ 

function whoIsWinner(){
    for (let i = 0; i < spaces.length; i++) {
        //rows
        if(spaces[0].id == correntPlayer && (spaces[0].id == spaces[1].id) && (spaces[0].id == spaces[2].id)){
            elmMessage.innerText = `player ${correntPlayer} has won`
            elmb4.disabled = true
            elmb5.disabled = true
            elmb6.disabled = true
            elmb7.disabled = true
            elmb8.disabled = true
            elmb9.disabled = true
            elmb1.style.backgroundColor = 'aqua'
            elmb2.style.backgroundColor = 'aqua'
            elmb3.style.backgroundColor = 'aqua'
            showPlayAgain()
        }else if(spaces[3].id == correntPlayer && (spaces[3].id == spaces[4].id) && (spaces[3].id == spaces[5].id)){
            elmMessage.innerText = `player ${correntPlayer} has won`
            elmb1.disabled = true
            elmb2.disabled = true
            elmb3.disabled = true
            elmb7.disabled = true
            elmb8.disabled = true
            elmb9.disabled = true
            elmb4.style.backgroundColor = 'aqua'
            elmb5.style.backgroundColor = 'aqua'
            elmb6.style.backgroundColor = 'aqua'
            showPlayAgain()
        }else if(spaces[6].id == correntPlayer && (spaces[6].id == spaces[7].id) && (spaces[6].id == spaces[8].id)){
            elmMessage.innerText = `player ${correntPlayer} has won`
            elmb1.disabled = true
            elmb2.disabled = true
            elmb3.disabled = true
            elmb4.disabled = true
            elmb5.disabled = true
            elmb6.disabled = true
            elmb7.style.backgroundColor = 'aqua'
            elmb8.style.backgroundColor = 'aqua'
            elmb9.style.backgroundColor = 'aqua'
            showPlayAgain()
        }else if(spaces[0].id == correntPlayer && (spaces[0].id == spaces[3].id) && (spaces[0].id == spaces[6].id)){
            //all the columns
            elmMessage.innerText = `player ${correntPlayer} has won`
            elmb5.disabled = true
            elmb2.disabled = true
            elmb3.disabled = true
            elmb6.disabled = true
            elmb8.disabled = true
            elmb9.disabled = true
            elmb1.style.backgroundColor = 'aqua'
            elmb4.style.backgroundColor = 'aqua'
            elmb7.style.backgroundColor = 'aqua'
            showPlayAgain()
        }else if(spaces[1].id == correntPlayer && (spaces[1].id == spaces[4].id) && (spaces[1].id == spaces[7].id)){
            elmMessage.innerText = `player ${correntPlayer} has won`
            elmb1.disabled = true
            elmb4.disabled = true
            elmb7.disabled = true
            elmb3.disabled = true
            elmb6.disabled = true
            elmb9.disabled = true
            elmb2.style.backgroundColor = 'aqua'
            elmb8.style.backgroundColor = 'aqua'
            elmb5.style.backgroundColor = 'aqua'
            showPlayAgain()
        }else if(spaces[2].id == correntPlayer && (spaces[2].id == spaces[5].id) && (spaces[2].id == spaces[8].id)){
            elmMessage.innerText = `player ${correntPlayer} has won`
            elmb1.disabled = true
            elmb2.disabled = true
            elmb4.disabled = true
            elmb5.disabled = true
            elmb7.disabled = true
            elmb8.disabled = true
            elmb3.style.backgroundColor = 'aqua'
            elmb6.style.backgroundColor = 'aqua'
            elmb9.style.backgroundColor = 'aqua'
            showPlayAgain()
        }else if(spaces[0].id == correntPlayer && (spaces[0].id == spaces[4].id) && (spaces[0].id == spaces[8].id)){
            //all the
            elmMessage.innerText = `player ${correntPlayer} has won`
            elmb4.disabled = true
            elmb2.disabled = true
            elmb6.disabled = true
            elmb3.disabled = true
            elmb7.disabled = true
            elmb8.disabled = true
            elmb1.style.backgroundColor = 'aqua'
            elmb5.style.backgroundColor = 'aqua'
            elmb9.style.backgroundColor = 'aqua'
            showPlayAgain()
        }else if(spaces[2].id == correntPlayer && (spaces[2].id == spaces[4].id) && (spaces[2].id == spaces[6].id)){
            elmMessage.innerText = `player ${correntPlayer} has won`
            elmb1.disabled = true
            elmb2.disabled = true
            elmb4.disabled = true
            elmb6.disabled = true
            elmb8.disabled = true
            elmb9.disabled = true
            elmb3.style.backgroundColor = 'aqua'
            elmb5.style.backgroundColor = 'aqua'
            elmb7.style.backgroundColor = 'aqua'
            showPlayAgain()
        }
    }
}


function showPlayAgain(){
    elmAgaintButton.style = 'visibility:visible';
}
function playAgain(){
    window.location.reload();
}