import { jwtDecode } from "jwt-decode"
import { createContext, useState } from "react"

interface AuthContextType{
    email:string|null
    isBusiness:boolean
    isAdmin:boolean
    isSignedIn:boolean
    UserDetails:UserIdType|undefined
    getToken:()=> Promise<string|null>
    signIn:(email:string, password:string) => Promise<void|string>
    signOut:() => void
    signUp: ({}:IUserDetails) => Promise<string|undefined>
    loadUserFromLS: ()=> void 
}

interface CustomJwtPayLoad {
  _id:string
  isBusiness:boolean
  isAdmin:boolean
  iat:number
}

interface UserIdType {
  name:{
    first:string
    middle:string
    last:string
  }
  phone:number
  image:{
    url:string
    alt:string
  }
  address:{
    state:string
    country:string
    city:string
    street:string
    houseNumber:number
    zip:number
  }
  isBusiness:boolean
  isAdmin:boolean
  _id:string
  iat:number
  createdAt:string
}

interface IUserDetails{
name:{
  first:string,
last:string,
}
email:string;
password:string,
address:{
  country:string,
city:string,
state:string,
street:string,
houseNumber:number,
}
phone:string,
image:{
  url:string,
  alt:string,
}
isBusiness:boolean
}


export const AuthContext = createContext<AuthContextType|undefined>(undefined);

export default function AuthProvider({children}:{children:React.ReactNode}) {
  
    const [email,setEmail] = useState<null|string>(null)
    const [isBusiness,setIsBusiness] = useState<boolean>(false)
    const [isAdmin,setIsAdmin] = useState<boolean>(false)
    const [isSignedIn, setIsSignedIn] = useState(false)
    const [UserDetails, setUserDetails] = useState<UserIdType|undefined>(undefined)

    const getUserById = async (UserId:string) => {
        try{
          const response = await fetch(`https://monkfish-app-z9uza.ondigitalocean.app/bcard2/users/6592f5fd12eedb1d946a5801`, {
            method:'GET',
            headers:{
            'Content-Type': 'application/json',
            'x-auth-token':'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NTkyZjVmZDEyZWVkYjFkOTQ2YTU4MDEiLCJpc0J1c2luZXNzIjp0cnVlLCJpc0FkbWluIjpmYWxzZSwiaWF0IjoxNzEwNTc4MTU5fQ.BhMJq_LaFdIwbec4NWh0WpDfpSB1BCGQqGKPwFLbuq4'
          }
          })
          const data:UserIdType = await response.json()
          setUserDetails(data)
          console.log(data);
          console.log(UserId);
          
        }catch(err){
        }
    }
    
    const signIn = async (email:string, password:string) => {
      try{
        const response = await fetch('https://monkfish-app-z9uza.ondigitalocean.app/bcard2/users/login', {
          method:'POST',
          headers:{'Content-Type': 'application/json'},
          body:JSON.stringify({email,password})
        })
        const data = await response.text()
        if (!response.ok) throw new Error(data)
        const decoded = jwtDecode<CustomJwtPayLoad>(data)
        setEmail(email)
        setIsSignedIn(true)
        setIsBusiness(decoded.isBusiness)
        setIsAdmin(decoded.isAdmin)
        
        localStorage.setItem('userToken', data)

        getUserById('')

      }catch(err){
        const errMessage = (err as Error).message
        return errMessage
      }
    }

    const signOut = () => {
      setEmail(null)
      setIsSignedIn(false)
      setIsAdmin(false)
      setIsBusiness(false)
      localStorage.removeItem('userToken')
    }

    const signUp = async (userSignupDetails:IUserDetails) => {
      try{
        const response = await fetch('https://monkfish-app-z9uza.ondigitalocean.app/bcard2/users', {
        method:'POST',
        headers:{'Content-Type': 'application/json'},
        body:JSON.stringify(userSignupDetails)
      })
      const data = await response.json()
      setUserDetails(data)
      if(response.ok){
      }
      if(!response.ok) return data
      console.log(data);
      return {error:undefined}
      }catch(err){
        const errMessage = (err as Error).message
        return {error:errMessage}
      }
    }

    const loadUserFromLS = ()=>{
      const userToken = localStorage.getItem('userToken')
      if(!userToken) return null
      const user = jwtDecode<CustomJwtPayLoad>(userToken)
      setIsSignedIn(true)
      setIsBusiness(user.isBusiness)
      setIsAdmin(user.isAdmin)
    }
   
    const getToken = async():Promise<string|null> =>{
      const token = localStorage.getItem('userToken')
      if(token){
        return token
      }else{
        return null
      }
    }

    return (
    <AuthContext.Provider value={{ isSignedIn, email, isBusiness, isAdmin,UserDetails, signIn,signOut, signUp, loadUserFromLS, getToken}}>
    {children}
    </AuthContext.Provider>
  )
}
