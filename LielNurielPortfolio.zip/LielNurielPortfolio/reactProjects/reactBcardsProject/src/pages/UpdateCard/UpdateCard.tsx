import { useState } from "react"
import { useNavigate, useParams } from "react-router-dom"




interface CardCreation {
  title:string,
  subtitle:string,
  description:string,
  phone:string,
  email:string,
  web:string,
  image:{
  url:string,
  alt:string,
  },
  address:{
    state:string
    country:string
    city:string
    street:string
    houseNumber:number
    zip:number
  },
  _id:string
}


export default function UpdateCard(props:CardCreation) {

  const { cardId } = useParams()
  const Navigate = useNavigate();
  const [title,setTitle] = useState<string>('')
  const [subtitle,setSubtitlel] = useState<string>('')
  const [description,setDescription] = useState<string>('')
  const [phone,setPhone] = useState<string>('')
  const [email,setEmail] = useState<string>('')
  const [web,setWeb] = useState<string>('')
  const [url,setUrl] = useState<string>('')
  const [alt,setAlt] = useState<string>('')
  const [country,setCountry] = useState<string>('')
  const [city,setCity] = useState<string>('')
  const [state,setState] = useState<string>('')
  const [street,setStreet] = useState<string>('')
  const [houseNumber,setHouseNumber] = useState<string>('')
  const [zip,setZip] = useState<string>('')
  const [newcardDetails,setNewCardDetails] = useState<CardCreation|undefined>(undefined)


  const handleSubmitEdit = async(e:React.FormEvent)=>{
    e.preventDefault();
    if(props){
      const newCardData = {
        title:title,
        email:email,
        subtitle:subtitle,
        description: description,
        address: {
          state:state,
          country:country,
          city:city,
          street:street,
          houseNumber:houseNumber,
          zip:zip
      },
        phone:phone,
        image:{
        url:'https://cdn.dribbble.com/users/40756/screenshots/6232646/side-profile-woman_2x_4x.png',
        alt:'picture',
      },
      }
      const isCreated = newcardDetails
      console.log(newCardData);
      Navigate('/Home')
      alert('Your card Updated Seccessfuly')
      if(isCreated){
      }else{
        return {Error}
      }
     }
    fetchEditedcard(props)
  }


  const fetchEditedcard = async(props:CardCreation)=>{
    try{
      const response = await fetch(`https://monkfish-app-z9uza.ondigitalocean.app/bcard2/cards/${cardId}`, {
      method:'PUT',
      headers:{'Content-Type': 'application/json',
      'x-auth-token':'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NTQyNGFlOWE4ZDFlYWUxMmQzMWUzNjAiLCJpc0J1c2luZXNzIjp0cnVlLCJpc0FkbWluIjpmYWxzZSwiaWF0IjoxNjk4ODQzNDQyfQ.znXbzyxMKeNrKf3dA8jXQ5CFptM8-iXjeFtqx3XfHD0',
    },
      body:JSON.stringify(props)
    })
    const data = await response.json()

    if(response.ok){
      setNewCardDetails(data)
    }
    if(!response.ok) return data
    return {error:undefined}
    }catch(err){
      const errMessage = (err as Error).message
      return {error:errMessage}
    }
  }

  return (
    <>
    <div className="EdirCard Home" style={{width:'60%',}}>
        <h4>Edit Mode</h4>
        <form onSubmit={handleSubmitEdit} className="row g-2 needs-validation">
  <div className="col-md-12">
    <label htmlFor="validationCustom01" className="form-label">Web</label>
    <input type="text" className="form-control" id="validationCustom01" value={web} onChange={(e)=>setWeb(e.target.value)} required/>
  </div>
  <div className="col-md-12">
    <label htmlFor="validationCustom01" className="form-label">Pictre url</label>
    <input type="url" className="form-control" id="validationCustom01" value={url} onChange={(e)=>setUrl(e.target.value)} required/>
  </div>
  <div className="col-md-12">
    <label htmlFor="validationCustom01" className="form-label">Alt</label>
    <input type="text" className="form-control" id="validationCustom01" value={alt} onChange={(e)=>setAlt(e.target.value)} required/>
  </div>
  <div className="col-md-12">
    <label htmlFor="validationCustom01" className="form-label">Title</label>
    <input type="text" className="form-control" id="validationCustom01" value={title} onChange={(e)=>setTitle(e.target.value)} required/>
    <div className="valid-feedback">
      Looks good!
    </div>
  </div>
  <div className="col-md-12">
    <label htmlFor="validationCustom02" className="form-label">Sub Title</label>
    <input type="text" className="form-control" id="validationCustom02" value={subtitle} onChange={(e)=>setSubtitlel(e.target.value)} required/>
    <div className="valid-feedback">
      Looks good!
    </div>
  </div>
  <div className="col-md-12">
    <label htmlFor="validationCustomUsername" className="form-label">Description</label>
    <div className="input-group has-validation">
      <span className="input-group-text" id="inputGroupPrepend"></span>
      <input type="text" className="form-control" id="exampleInputEmail3" value={description} onChange={(e)=>setDescription(e.target.value)} required/>
    </div>
  </div>
  <div className="col-md-12">
    <label htmlFor="validationCustomUsername" className="form-label">Email</label>
    <div className="input-group has-validation">
      <span className="input-group-text" id="inputGroupPrepend">*</span>
      <input type="email" className="form-control" id="validationCustomUsername" aria-describedby="emailHelp" value={email} onChange={(e)=>setEmail(e.target.value)} required/>
      <div className="invalid-feedback">
        You must contain a valid email.
      </div>
    </div>
  </div>
  <div className="col-md-12">
    <label htmlFor="validationCustom05" className="form-label">Phone Number</label>
    <input type="phone" className="form-control" id="validationCustom08" value={phone} onChange={(e)=>setPhone(e.target.value)} required/>
    <div className="invalid-feedback">
      Please provide a valid Phone Number.
    </div>
  </div>
  <div className="col-md-12">
    <label htmlFor="validationCustom03" className="form-label">Country</label>
    <input type="text" className="form-control" id="validationCustom03" value={country} onChange={(e)=>setCountry(e.target.value)} required/>
    <div className="invalid-feedback">
      Please provide a valid adress.
    </div>
  </div>
  <div className="col-md-12">
    <label htmlFor="validationCustom03" className="form-label">city</label>
    <input type="text" className="form-control" id="validationCustom04" value={city} onChange={(e)=>setCity(e.target.value)} required/>
    <div className="invalid-feedback">
      Please provide a valid adress.
    </div>
  </div>
  <div className="col-md-12">
    <label htmlFor="validationCustom03" className="form-label">State</label>
    <input type="text" className="form-control" id="validationCustom05" value={state} onChange={(e)=>setState(e.target.value)} required/>
    <div className="invalid-feedback">
      Please provide a valid adress.
    </div>
  </div>
  <div className="col-md-12">
    <label htmlFor="validationCustom03" className="form-label">Street</label>
    <input type="text" className="form-control" id="validationCustom06" value={street} onChange={(e)=>setStreet(e.target.value)} required/>
    <div className="invalid-feedback">
      Please provide a valid adress.
    </div>
  </div>
  <div className="col-md-12">
    <label htmlFor="validationCustom03" className="form-label">HouseNumber</label>
    <input type="text" className="form-control" id="validationCustom07" value={houseNumber} onChange={(e)=>setHouseNumber(e.target.value)} required/>
    <div className="invalid-feedback">
      Please provide a valid adress.
    </div>
  </div>
  <div className="col-md-12">
    <label htmlFor="validationCustom03" className="form-label">Zip</label>
    <input type="text" className="form-control" id="validationCustom07" value={zip} onChange={(e)=>setZip(e.target.value)} required/>
    <div className="invalid-feedback">
      Please provide a valid adress.
    </div>
  </div>
  <div className="col-12">
    <button className="btn btn-danger" type="submit">Submit</button>
  </div>
</form>
</div>
</>
  )
}
