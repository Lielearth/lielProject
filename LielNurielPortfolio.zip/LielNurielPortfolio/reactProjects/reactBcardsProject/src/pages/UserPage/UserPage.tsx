import { useContext } from "react"
import { AuthContext } from "../../context/AuthContext"
import { Link } from "react-router-dom"

export default function UserPage() {

    const auth = useContext(AuthContext)

  return (
    <>
    <div className="UserPage">
      <h3>User Page</h3>
      <br />
        {
          (auth?.isSignedIn)?
          <>
          <p>Welcome {auth.UserDetails?.name.first} what would you like to do:</p>
          <Link to={'/UserProfile'} className="btn btn-danger" >User Profile</Link>
          <br /><br />
          <Link to={'/Favorites'} className="btn btn-danger" >See Favorite Cards</Link>
          </>
          :
          <>
          <p>You have to sign in to see this page, please sign in or sign up</p>
          <Link to="/signIn">sign-in</Link>
          <Link to="/signUp">sign-Up</Link>
          </>
        }
    </div>
    </>
  )
}
