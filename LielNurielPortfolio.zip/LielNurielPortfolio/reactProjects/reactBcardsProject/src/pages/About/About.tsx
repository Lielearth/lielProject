import './About.css'

export default function About() {
  return (
    <div className='About Page'>
      <br/><br/>
      <h1>Abute Us</h1>
      <br/>
            <h3>Design Custom Business Cards Online with BCards</h3><br/>
            <h4>How can we help you?</h4><br/>  
            <p>
When it comes to creating professional and eye-catching business cards, **BCards** is a go-to platform.<br/>
With our business card maker, you can easily create unique cards that leave a lasting impression. <br/>
We have an Easy Customization: Start with a template, personalize it by adding your details to match your brand.<br/>
Whether you need standard business cards or something more specialized, <br/>
BCards' user-friendly interface and professional template make the process seamless. <br/>
Make a great first impression with BCards! 🌟<br/>
          </p>
    </div>
  )
}
