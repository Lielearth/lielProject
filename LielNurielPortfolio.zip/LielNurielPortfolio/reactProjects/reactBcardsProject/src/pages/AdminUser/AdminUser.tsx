import { useContext } from "react"
import { AuthContext } from "../../context/AuthContext"
import { Link } from "react-router-dom"

export default function AdminUser() {

    const auth = useContext(AuthContext)

  return (
    <div className="AdminUser">
        <h3>Admin Page</h3>
        <br />
        {
          (auth?.isSignedIn && auth.isAdmin) ?
          <p>Welcome! you are signed in</p>
          :
          <>
          <p>You have to sign in to see this page, please sign in or sign up</p>
          <Link to="/signIn">sign-in</Link>
          <Link to="/signUp">sign-Up</Link>
          </>
        }
    </div>
  )
}
