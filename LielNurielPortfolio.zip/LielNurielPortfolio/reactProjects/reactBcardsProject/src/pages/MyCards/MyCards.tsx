import { Link, useParams } from 'react-router-dom'
import { useEffect, useState } from 'react'
import { Button } from 'react-bootstrap'
import { MdOutlineDeleteForever } from "react-icons/md";



interface Icard {
    _id:string
    title:string
    description:string
    image:{url:string, alt:string}
    bizNumber:number
    user_id:string
    phone:number
    address:{country:string, city:string}
  }
  
 

export default function MyCards() {


    const [cards, setCards] = useState<null|Icard[]>(null)
    const [error, setError] = useState<null|string>(null)
    const {cardId} = useParams()
    

    useEffect( ()=> {
        const fetchMyCards = async() =>{
          try{
            const token = localStorage.getItem('userToken')
            if(!token) return {error:'no token'}
            const response = await fetch('https://monkfish-app-z9uza.ondigitalocean.app/bcard2/cards/my-cards', {
              method:'GET',
              headers:{
            'Content-Type': 'application/json',
             'x-auth-token': token,
            }
            })
            const data = await response.json()  
            setCards(data)
          }catch(err){
            const errMessage = (err as Error).message
            setError(errMessage)
          }
        }
        fetchMyCards()
        }
        ,[]
        )


        
          const deleteCard = async(cardId:string) =>{
            try{
              const token = localStorage.getItem('userToken')
              if(!token) return {error:'no token'}
              const response = await fetch(`https://monkfish-app-z9uza.ondigitalocean.app/bcard2/cards/${cardId}`, {
                method:'DELETE',
                headers:{
              'Content-Type': 'application/json',
               'x-auth-token': token,
              }
              })
              const data = await response.json()  
              setCards(data)
            }catch(err){
              const errMessage = (err as Error).message
              setError(errMessage)
            }
          }
         


  return (
    <>
    <div className="MyCards Home">
        <h3>My Cards</h3>
        <br /><br />
        <Link to={'/CreateCard'} className='btn btn-danger'>Create a card</Link>
        <br /><br />
        {(error) && <p>Error getting cards! <br />{error}</p>}
        <div className='container'>
        {
          (cards)?
          cards.map((card)=>
          <div className="card" key={card._id}>
          <img src={card.image.url} className="card-img-top" alt={card.image.alt}/>
         <div className="card-body text-bg-dark">
         <h5 className="card-title">{card.title}</h5>
         <p className="card-text">{card.description}</p>
         <p className="card-text">{card.bizNumber}</p>
         <Link to={'/UpdateCard'} className="btn btn-danger">UpdateCard</Link>
         <Button variant='danger' onClick={()=>deleteCard(card._id)}><MdOutlineDeleteForever /></Button>
         </div>
         </div>
            )
          :
          (!error) && 'No cards'
        }
      </div>
    </div>
    </>
  )
}
