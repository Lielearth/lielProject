# React + TypeScript + Vite

read me:
In this project i worked with an API to get, edit and delete business cards,
mark your favorite cards and see them in your favorites page if you're signed in, 
you have an ability to create your own cards only if you are a business user. 

I used react bootstrap and react icons for the overall design.

If you are having trouble to use this website please contact me.

IMPORTENT! :

After opening the files - in the terminal- type- npm i - and afterwards - npm run dev.

Then you would be able to see the project.-