'use strict'

//references
const elmGuessInput = document.querySelector('#guessInput');
const elmLastGuess = document.querySelector('.number');
const elmScore = document.querySelector('.score');
const elmHighScore = document.querySelector('.highscore');
const elmMessage = document.querySelector('.message');
const elmBody = document.querySelector('body');
const elmCheckButton = document.querySelector('#checkButton');

//veriables
let score = 100;
let highscore = 0;
let secretNumber = Math.trunc((Math.random()*20)+1)


console.log(secretNumber);

function again(){
score=100;
secretNumber = Math.trunc((Math.random()*20)+1);
elmScore.innerText = 100;
elmGuessInput.value = '';
elmLastGuess.innerText = '?';
elmMessage.innerText = 'Start Guessing'
elmBody.style.backgroundColor = '#222';
elmCheckButton.disabled = false;
}


function check(){
    const guess = Number(elmGuessInput.value);

    if(guess<1||guess>20){
      elmMessage.innerText = 'Enter a number between 1 and 20';
      elmLastGuess.innerText = '?';
      elmBody.style.backgroundColor = '#222';
      return;
    }
    if(guess === secretNumber){   //if user guessed correctly
      elmLastGuess.innerText = guess;
      elmMessage.innerText = 'You guessed it right!';
      elmBody.style.backgroundColor = '#41692d';
      if(score>highscore) {
        highscore = score;
        elmHighScore.innerText = highscore;
      }
    }else{
      elmLastGuess.innerText = guess;
      elmMessage.innerText = (guess > secretNumber) ? 'Too High' : 'Too Low';
      elmBody.style.backgroundColor = '#8a2727';
      score -= 10;
      elmScore.innerText = score;
      if(score === 0) {
        elmMessage.innerText = 'Game Over! Try Again'
        elmCheckButton.innerText = "Press 'Again'";
        elmCheckButton.disabled = true;
      }
    }
}