'use strict'

// Variables

let products = []
let urlGetAllProducts = 'https://dummyjson.com/products'

// Referances

const elmTitle = document.querySelector('#title')
const elmPrice = document.querySelector('#price')
const elmBrand = document.querySelector('#brand')
const elmStock = document.querySelector('#stock')

const elmProductsList = document.querySelector('#products-list')
const elmAddProduct = document.querySelector('#add-product-panel')
const elmUpdateProduct = document.querySelector('#update-product-panel')

// Events

document.addEventListener('DOMContentLoaded', () => fetchAndDisplayProducts() )

//  get the products from server Function

const fetchAndDisplayProducts = async () => {
  products = await fetchAllProducts()
  displayProducts()
}

const fetchAllProducts = async () => {
  const response = await fetch(urlGetAllProducts)
  const data = await response.json()
  return data.products
}

const beforeAddProduct = async () => {

  disableAllButtons()

  const title = document.querySelector('#add-product-input-title')
  const price = document.querySelector('#add-product-input-price')
  await addProduct(
    title.value,
    parseFloat(price.value),
    )

  disableAllButtons()

  title.value = ''
  price.value = ''

  hideAddProductOption()
}

const beforeUpdateProduct = async () => {
  disableAllButtons()

  const id = document.querySelector('#update-product-input-id')
  const title = document.querySelector('#update-product-input-title')
  const price = document.querySelector('#update-product-input-price')

  await updateProduct(
    parseInt(id.value),
    title.value,
    parseFloat(price.value),
    )

  disableAllButtons()

  id.value = ''
  title.value = ''
  price.value = ''

  hideUpdateProducts()

  afterUpdateProduct()
}

const afterUpdateProduct = () => {
  fetchAndDisplayProducts()
}

const displayAndPopulateUpdatePanel = async (productId) => {
  showUpdateProductOption()
  const response = await fetch(`https://dummyjson.com/products/${productId}`)
  const data = await response.json()
  document.querySelector('#update-product-input-id').value = data.id
  document.querySelector('#update-product-input-title').value = data.title
  document.querySelector('#update-product-input-price').value = data.price
}

const displayProducts = () => {
  let html =
      `
      <div class="products-header">
        <div class="pageTitle">Products List Manegement</div>
        <div class="cursor-pointer" onclick="showAddProductOption()">( + Add )</div>
      </div>
      `
  for (let i=0; i<products.length; i++) {
    html += `
    <div class='product-row' onclick='displayAndPopulateUpdatePanel(${products[i].id})'>
      <div>${products[i].id}</div>
      <div>${products[i].title}</div>
      <div>${products[i].price}</div>
      <div onclick="beforeDeleteProduct(event,${products[i].id})">X</div>
    </div>
    `
  }

  elmProductsList.innerHTML = html;
}


const beforeDeleteProduct = async (e, productId) => {
  e.stopPropagation()
  await deleteProduct(productId)
  fetchAndDisplayProducts()
}


const disableAllButtons = () => {
  const allButtons = document.querySelectorAll('button')
  allButtons.forEach((button)=>{
    button.toggleAttribute('disabled')
  })
}

const showAddProductOption = () => {
  elmAddProduct.classList.remove('hidden')
}

const hideAddProductOption = () => {
  elmAddProduct.classList.add('hidden')
}

const showUpdateProductOption = () => {
  elmUpdateProduct.classList.remove('hidden')
}

const hideUpdateProducts = () => {
  elmUpdateProduct.classList.add('hidden')
}

//to get the spesific product from server
const getProduct = async () => {
  const response = await fetch('https://dummyjson.com/products/1',{method:'GET'})
  const data = await response.json()
  console.log(data)
}

//the option to delete a spesific product
const deleteProduct = async (productId) => {
  const response = await fetch(`https://dummyjson.com/products/${productId}`,{method:'DELETE'})
  const data = await response.json()
  console.log(data)
}

//the option to add a product
const addProduct = async (title,price) => {
  const productToAdd = {
    title: title,
    price: price,
  }
  
  const addOptions = {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify( productToAdd )
  }

  const response = await fetch('https://dummyjson.com/products/add', addOptions)
  const data = await response.json()
  console.log(data)
}

//the option to update a spesific product
const updateProduct = async (id, title,price) => {
  const updatesToProduct = {
    title: title,
    price: price,
  }
  
  const updateOptions = {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify( updatesToProduct )
  }

  const response = await fetch(`https://dummyjson.com/products/${id}`, updateOptions)
  const data = await response.json()
  console.log(data)
}
