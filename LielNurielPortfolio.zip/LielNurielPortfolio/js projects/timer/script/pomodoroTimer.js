'use strict'

//reach to elements in the Dom
const elmSecondsCounter = document.querySelector('#counterSeconds');
const elmMinutesCounter = document.querySelector('#counterMinutes');
const elmHoursCounter = document.querySelector('#counterHours');

//Starting point - veraibles

//standart pomodoro
let secondsCouter = 60;
let minutesCouter = 29;
let hoursCounter = 1;
let myCounterS;
let myCounterM;
let myCounterH;


function startCountingSeconds() {
    secondsCouter--;
    elmSecondsCounter.innerText = secondsCouter;
    if(secondsCouter === 0) {
        secondsCouter = 60;
        secondsCouter--;
        elmSecondsCounter.innerText = secondsCouter;
    }
}
function startCountingMinutes() {
    minutesCouter--;
    elmMinutesCounter.innerText = minutesCouter;
    if(minutesCouter === 0){
        minutesCouter = 59;
        minutesCouter--;
        elmMinutesCounter.innerText = minutesCouter;
        hoursCounter = 0;
        elmHoursCounter.innerText = hoursCounter;
    }
}
function startCountingHours() {
    hoursCounter--;
    elmHoursCounter.innerText = hoursCounter;
}

function standartPomodoro() {

    elmHoursCounter.innerText = hoursCounter;
    elmMinutesCounter.innerText = minutesCouter;
    elmSecondsCounter.innerText = secondsCouter;
    myCounterS = setInterval(startCountingSeconds, 1000);
    myCounterM = setInterval(startCountingMinutes, 60000);
    myCounterH = setInterval(startCountingHours, 3540000);

    if((minutesCouter === 0) && (secondsCouter === 0) && (hoursCounter === 0)){
        clearInterval(myCounterS);
        clearInterval(myCounterM);
        clearInterval(myCounterH);
    }
}

function stopTimer() {
    clearInterval(myCounterH);
    clearInterval(myCounterM);
    clearInterval(myCounterS);
}

